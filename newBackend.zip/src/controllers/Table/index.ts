import { tableResolvers } from "./resolvers";
import { tableTypeDefs } from "./typeDefs";




export { tableResolvers, tableTypeDefs };
